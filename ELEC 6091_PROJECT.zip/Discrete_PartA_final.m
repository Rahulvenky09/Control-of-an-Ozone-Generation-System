clc
clear all

%%%Component Modelling
% Valve V1
v1c = 101;
v1o = 102;
V1 = automaton(2, [1 v1o 2; 1 v1c 1; 2 v1c 1; 2 v1o 2],[1]);

% Valve V2
v2c = 111;
v2o = 112;
V2 = automaton(2, [1 v2o 2; 1 v2c 1;  2 v2c 1; 2 v2o 2],[1]);

% Valve V3
v3c = 121;
v3o = 122;
V3 = automaton(2, [1 v3o 2; 1 v3c 1; 2 v3c 1; 2 v3o 2],[1]);

% Flow F1
f1u = 131;
f1d = 132;
F1 = automaton(2, [1 f1u 2; 2 f1d 1], [1]);

% Flow F2
f2u = 141;
f2d = 142;
F2 = automaton(2, [1 f2u 2; 2 f2d 1], [1]);

% Analyzer A1
a1u = 151;
a1d = 152;
A1 = automaton(2, [1 a1u 2; 2 a1d 1], [1]);

% Power Supply Unit (PSU)
Pon = 161;
Poff = 162;
PSU = automaton(2, [1 Pon 2; 1 Poff 1; 2 Poff 1; 2 Pon 2],[1]);

% Master Controller (MC)
Mstart = 171;
Mshut = 172;
MC = automaton(1, [1 Mstart 1; 1 Mshut 1], [1]);

% Communicator (CN)
Cstart = 181;
Cshut = 182;
CN = automaton(1, [1 Cstart 1; 1 Cshut 1], [1]);


%%%Interactions

%Sync V1 and F1
Int1 = automaton(2, [1 v1o 2; 1 v1c 1; 1 f1d 1; 2 v1c 1; 2 v1o 2; 2 f1u 2; ],[1]);
display(Int1)

%Sync V2 and V3
[Int2, states_2] = sync(V2,V3);
for i=1:size(states_2,1)
   if (states_2(i,1)==2  && states_2(i,2)==2) 
     Int2.TL=[Int2.TL; i f2u i];  
   else
     Int2.TL=[Int2.TL; i f2d i];
   end
end
display(Int2)

%Sync F1 and PSU
[Int3, states_3] = sync(F1,PSU);
for i=1:size(states_3,1)
   if (states_3(i,1)==2  && states_3(i,2)==2) 
     Int3.TL=[Int3.TL; i a1u i];  
   else
     Int3.TL=[Int3.TL; i a1d i];
   end
end
display(Int3)

%%%Combine Models
SYS = sync(V1,V2,V3,F1,F2,A1,PSU,CN,MC,Int1,Int2,Int3)
display(SYS)

%%%SPECIFICATION 1
Specification1 = automaton(10,[1 Mstart 2; 1 Mshut 1; 2 f1u 3;  2 Mshut 2; 2 Mstart 2; 3 f2u 4; 3 Mshut 3; 3 Mstart 3; 4 Pon 5; 4 Mshut 4; 4 Mstart 4; 5 Cstart 6; 5 Mshut 5; 5 Mstart 5; 6 Mshut 7; 6 Mstart 6; 7 Poff 8; 7 Mshut 7; 7 Mstart 7; 8 f2d 9; 8 Mshut 8; 8 Mstart 8; 9 f1d 10; 9 Mshut 9; 9 Mstart 9; 10 Cshut 1; 10 Mshut 10; 10 Mstart 10],[1,2,3,4,5,6,7,8,9,10]);
%Events that are not controllable
Euc = [f1u, f1d, f2u, f2d, a1u, a1d, Mstart, Mshut];
%Adding selfloops
Specification1_Final = selfloop(Specification1,[v1c, v1o, v2c, v2o, v3c, v3o, a1d, a1u])
display(Specification1);

%Chceking Controllability for the specification 
Test_controllable = controllable(SYS, Specification1_Final, Euc);
disp('Test_Controllable');

%%%Designing a Supervisor that is controllable and represent it as  C
C = supcon(Specification1_Final,SYS,Euc)
% Obtaining desired Supervisor 
s = 1:1:C.N;
Desired_supervisor = automaton(C.N, C.TL, [s])

%Checking conditions to satisy proper supervisor
%Checking whether it is controllable                            
Desired_supervisor_controllable = controllable(Desired_supervisor,SYS,Euc);
disp('Desired_supervisor_controllable');

% Checking whether the system satisfies Non-Blocking Condition 
GR = product(SYS,Desired_supervisor);
GR_trim = trim(GR);
if(GR.N == GR_trim.N)
    disp('System under Supervision satisfies Non-Blocking condition');
else
    disp('System under Supervision does not satisfy Non-blocking condition');
end

%%%Designing a Supervisor that is controllable and represent it as  C
C = supcon(Specification1_Final,SYS,Euc)
% Obtaining desired Supervisor 
s = 1:1:C.N;
Desired_supervisor = automaton(C.N, C.TL, [s])

%Checking conditions to satisy proper supervisor
%Checking whether it is controllable                            
Desired_supervisor_controllable = controllable(Desired_supervisor,SYS,Euc);
disp('Desired_supervisor_controllable');

% Checking whether the system satisfies Non-Blocking Condition 
GR = product(SYS,Desired_supervisor);
GR_trim = trim(GR);
if(GR.N == GR_trim.N)
    disp('System under Supervision satisfies Non-Blocking condition');
else
    disp('System under Supervision does not satisfy Non-blocking condition');
end
%Checking whether the system satisfies specification1_Final
Test = product(GR,complement(Specification1_Final));
if(size(Test.Xm) == [1 0])
  disp('Conditions are satisfied')
else
    ;
end

% Using Project condition as it is given in the question
F1= project(C,[v1o v1c v2o v2c v3o v3c a1d a1u])
F1.TL
F1.Xm

%Checking a random sequence of supervisor
S_check1=[1 Mstart 2; 2 f1u 3; 3 f2u 4; 4 Pon 5; 5 Cstart 6; 6 Mshut 7; 7 Poff 8; 8 f2d 9; 9 f1d 10];
CHECK1=automaton(10,S_check1,[1 2 10])
S_PRODUCT1=product(C,CHECK1)

%Check whether it is a subset of supervisor
Finally_1 = product(S_PRODUCT1, complement(C))
